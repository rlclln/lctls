function [alpha_1] = f_7(M1,M2,M3)

M = length(M1);
cvx_clear
cvx_begin sdp
cvx_solver   sedumi% sdpt3
cvx_quiet(1)
cvx_precision best %������������˱���
    variable alpha_1(1)
    variable beta_1(1)
    maximize alpha_1
    subject to
        M1-alpha_1*M2+beta_1*M3>=zeros(M,M);
        beta_1>=0;
cvx_end
end