
clc
clear all
close all
tic

datestr(now,13) %
MC = 5; % how many runs��Monte Carlo
p = 10; % maximal NLOS value
N = 8; % number of anchors


s(:,1) = [-20;-20];
s(:,2) = [-20;20];
s(:,3) = [20;-20];
s(:,4) = [20;20];
s(:,5) = [-20;0];
s(:,6) = [0;-20];
s(:,7) = [0;20];
s(:,8) = [20;0];



nrange = [0,8];
    
sigma_1 = [];
    K = 0.4:0.4:2;
    for m = 1:5
        sigma = 0.4*m;
 
        Q = 0.5*sigma^2*(eye(N)+ones(N,N));
        for j = 1:MC  
            j;
            
            NLOS_number = randi(nrange,1,1); 
 
            n = gauss_samples(zeros(N,1),Q,1); 
            
            x = unifrnd(-25,25);
            y = unifrnd(-25,25);
            X = [x;y];

            w_toa = [];
            for i = 1:N 
                w_toa(i) = unifrnd(0,p);
            end
            
            g_index = randperm(8,NLOS_number); 
            g_toa = zeros(N,1);
            g_toa(g_index) = 1;


            d_toa = zeros(N,1);	
            r_toa = zeros(N,1);	
            b_toa = zeros(N,1);
            e_toa = zeros(N,1);


            for k = 1:N
                d_toa(k,:) = norm(X-s(:,k));
                e_toa(k,:) = g_toa(k)*w_toa(k);
                r_toa(k,:) = d_toa(k)+e_toa(k,:)+n(k);	
                b_toa(k,:) = s(:,k)'*s(:,k)-(r_toa(k,:)-e_toa(k,:))^2+2*(r_toa(k,:)-e_toa(k,:))*n(k);

            end
            
%%%%%%%%%%%%%%% lctls.m   %%%%%%%%%%%%%%%%%%%%%%            
            xi = sigma;
            y0 = lctls(s,b_toa,xi);
            X0 = [y0(1);y0(2)];

            t00(j,1) = norm(X0-X);
       
            
        end

        RMSE0(m) = sqrt(sum(t00)/MC);
        
    end

        

datestr(now,13) %���н���ʱ��
toc
