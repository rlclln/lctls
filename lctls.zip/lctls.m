function [theta_1] = rtls_sdp(s,b_toa,xi)
% INPUT:
% s: sensors' positon
% b_toa: measurement range
% xi:(sigma) standard deviation of measurement range
% N: Number of sensor nodes.

% OUTPUT: 
% theta_1:estimation position of target node.
% theta = [];
[dim,N] = size(s);
A = [2.*s',-1*ones(N,1)];	
V = [1,1,0];
L = diag(V); 
% U = [0,0,1];
% R = diag(U);
q = [0;0;-1/2];
L_G = length(L);

A_1 = A'*A;	%sym
b_1 = -A'*b_toa;
c_1 = b_toa'*b_toa;
A_2 = eye(3);
b_2 = zeros(3,1);
c_2 = 1;
A_3 = L'*L;
b_3 = q;
c_3 = -xi;

R1 = [A_1 b_1;b_1' c_1];	
R2 = eye(4);	
R3 = [A_3 b_3;b_3' c_3];

alpha_1 = f_7(R1,R2,R3); %
%%
cvx_clear   
cvx_begin sdp %quiet
cvx_solver SeDuMi% sdpt3 
cvx_quiet(1)
cvx_precision best 
    variable theta_1(3,1)
    
    minimize transpose(theta_1)*(A_1-alpha_1*A_2)*theta_1+2*transpose(b_1-alpha_1*b_2)*theta_1+c_1-alpha_1*c_2
    subject to
    theta_1'*A_3*theta_1+2*q'*theta_1 <= xi;

cvx_end

end
